import { useState, useMemo, useEffect } from 'react'
import { contactsService } from '../../services/contacts.service'

const AREAS = [
  'Administração Pessoal',
  'Administrativo Urbanismo',
  'Agropecuária',
  'Almoxarifado',
  'Apoio',
  'Arquitetura',
  'Assuntos Regulatórios',
  'Atendimento',
  'Brigada',
  'Comercial',
  'Compras',
  'Conservação',
  'Contabilidade',
  'Controladoria',
  'Engenharia',
  'Estacionamento',
  'Experiência Urbanismo',
  'Family Office',
  'Financeiro',
  'Helicenter',
  'In Concert',
  'Incorporação',
  'Inovação',
  'Instituto Flamboyant',
  'Jurídico',
  'Legalização',
  'Manutenção',
  'Marketing Corporativo',
  'Marketing Institucional',
  'Marketing Urbanismo',
  'Operações',
  'Pessoas e Cultura',
  'Planejamento e Projetos',
  'Planejamento Financeiro',
  'Planejamento Financeiro e Administrativo',
  'Planejamento Financeiro Urbanismo',
  'Processos',
  'Produtos e Projetos Urbanismo',
  'Produtos Urbanismo',
  'Projetos Executivos',
  'Projetos Urbanismo',
  'Recebimento Fiscal',
  'Relacionamento',
  'Resíduos',
  'Secretaria',
  'Segurança',
  'Suprimentos',
  'Tecnologia da Informação',
  'Vendas',
]

const TrashIcon = ({ color = '#E24B4A' }) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="3 6 5 6 21 6"/>
    <path d="M19 6l-1 14H6L5 6"/>
    <path d="M10 11v6M14 11v6"/>
    <path d="M9 6V4h6v2"/>
  </svg>
)

function PeopleRow({ users, selected, excluded = [], onAdd, onRemoveRow, canRemoveRow }) {
  const [area, setArea] = useState('')
  const [userId, setUserId] = useState('')
  const [manualMode, setManualMode] = useState(false)
  const [manualName, setManualName] = useState('')
  const [contacts, setContacts] = useState([])

  useEffect(() => {
    if (!area) return
    contactsService.list(area).then(r => setContacts(r.data)).catch(() => {})
  }, [area])

  const filteredUsers = useMemo(() => {
    if (!area) return []
    const systemUsers = users.filter(u =>
      u.area === area &&
      !selected.find(s => s.user_id === u.id) &&
      !excluded.find(e => e.user_id === u.id)
    )
    const filteredContacts = contacts.filter(c =>
      !selected.find(s => s.name === c.name && s.area === c.area) &&
      !excluded.find(e => e.name === c.name && e.area === c.area)
    ).map(c => ({ id: `contact_${c.id}`, name: c.name, area: c.area, isContact: true }))
    return [...systemUsers, ...filteredContacts]
  }, [area, users, contacts, selected, excluded])

  const noUsersFound = area && filteredUsers.length === 0

  const handleAreaChange = (e) => {
    setArea(e.target.value)
    setUserId('')
    setManualMode(false)
    setManualName('')
  }

  const handleUserChange = (e) => {
    const val = e.target.value
    if (!val) return
    if (val === '__manual__') {
      setManualMode(true)
      setUserId('')
      return
    }
    if (val.startsWith('contact_')) {
      const contact = filteredUsers.find(u => u.id === val)
      if (contact) {
        onAdd({ user_id: `manual_${Date.now()}`, name: contact.name, area: contact.area })
        setUserId('')
        setArea('')
      }
      return
    }
    const user = users.find(u => u.id === val)
    if (user) {
      onAdd({ user_id: user.id, name: user.name, area: user.area })
      setUserId('')
      setArea('')
      setManualMode(false)
    }
  }

  const handleManualAdd = async () => {
    if (!manualName.trim()) return
    try {
      await contactsService.create(manualName.trim(), area)
    } catch {}
    onAdd({ user_id: `manual_${Date.now()}`, name: manualName.trim(), area })
    setManualName('')
    setArea('')
    setManualMode(false)
  }

  const selectCls = 'h-9 w-full px-3 text-sm border border-gray-200 rounded-lg outline-none focus:border-primary-600 transition-colors bg-white text-gray-700'

  return (
    <div className="flex flex-col gap-1">
      <div className="flex items-end gap-2">
        <div className="flex-1">
          <p className="text-xs text-gray-400 mb-1">Área</p>
          <select value={area} onChange={handleAreaChange} className={selectCls}>
            <option value="">Selecionar área</option>
            {AREAS.map(a => <option key={a} value={a}>{a}</option>)}
          </select>
        </div>
        <div className="flex-1">
          <p className="text-xs text-gray-400 mb-1">Nome</p>
          {!area ? (
            <select disabled className={selectCls} style={{ opacity: 0.6, cursor: 'not-allowed' }}>
              <option>Selecione a área primeiro</option>
            </select>
          ) : noUsersFound || manualMode ? (
            <div className="flex items-center gap-1">
              <input
                type="text"
                value={manualName}
                onChange={e => setManualName(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleManualAdd()}
                placeholder="Digite o nome manualmente"
                autoFocus={manualMode}
                className={selectCls}
              />
              <button
                type="button"
                onClick={handleManualAdd}
                disabled={!manualName.trim()}
                className="text-xs text-white bg-primary-600 hover:bg-primary-800 disabled:opacity-40 transition-colors shrink-0 px-3 h-9 rounded-lg font-medium"
              >
                Adicionar
              </button>
              {manualMode && !noUsersFound && (
                <button
                  type="button"
                  onClick={() => { setManualMode(false); setManualName('') }}
                  className="text-xs text-gray-400 hover:text-gray-600 transition-colors shrink-0 px-2 h-9 border border-gray-200 rounded-lg bg-white"
                  title="Voltar para lista"
                >
                  ↩
                </button>
              )}
            </div>
          ) : (
            <select value={userId} onChange={handleUserChange} className={selectCls}>
              <option value="">Selecione o nome</option>
              {filteredUsers.filter(u => !u.isContact).map(u => (
                <option key={u.id} value={u.id}>{u.name}</option>
              ))}
              {filteredUsers.filter(u => u.isContact).length > 0 && (
                <option disabled>── Contatos cadastrados ──</option>
              )}
              {filteredUsers.filter(u => u.isContact).map(u => (
                <option key={u.id} value={u.id}>{u.name}</option>
              ))}
              <option value="__manual__">Digite o nome manualmente</option>
            </select>
          )}
        </div>
        {canRemoveRow && (
          <button
            type="button"
            onClick={onRemoveRow}
            className="h-9 w-9 flex items-center justify-center hover:opacity-70 transition-opacity shrink-0"
          >
            <TrashIcon />
          </button>
        )}
      </div>
      {(noUsersFound || manualMode) && (
        <p className="text-xs text-amber-600 mt-0.5">
          {noUsersFound
            ? 'Nenhum usuário encontrado nesta área. Digite o nome manualmente e clique em adicionar.'
            : 'Digite o nome e pressione Enter ou clique em adicionar.'}
        </p>
      )}
    </div>
  )
}

export function PeopleSelector({ label, required = false, users = [], selected = [], onChange, buttonLabel, allowEmptyStart = false, excluded = [] }) {
  const [rows, setRows] = useState(allowEmptyStart ? [] : (selected.length > 0 ? [] : [Date.now()]))

  const handleAdd = (person) => {
    onChange([...selected, person])
    setRows(prev => prev.slice(0, -1))
  }

  const handleRemoveSelected = (userId) => {
    const next = selected.filter(s => s.user_id !== userId)
    onChange(next)
    if (next.length === 0 && !allowEmptyStart) {
      setRows([Date.now()])
    }
  }

  const handleAddRow = () => {
    setRows(prev => [...prev, Date.now()])
  }

  const handleRemoveRow = (rowId) => {
    setRows(prev => prev.filter(r => r !== rowId))
  }

  return (
    <div className="flex flex-col gap-2">
      <label className="text-xs font-medium text-gray-500">
        {label} {required && <span className="text-red-400">*</span>}
      </label>

      {selected.length > 0 && (
        <div className="flex flex-col gap-2">
          {selected.map(s => (
            <div
              key={s.user_id}
              className="flex items-center justify-between border border-gray-200 rounded-lg px-3 py-2 bg-white"
            >
              <div className="flex items-center gap-0 w-full">
                <span className="text-xs text-gray-400 w-32 shrink-0">{s.area}</span>
                <div className="w-px h-3 bg-gray-200 shrink-0" />
                <span className="text-sm font-medium text-gray-800 ml-3">{s.name}</span>
              </div>
              <button
                type="button"
                onClick={() => handleRemoveSelected(s.user_id)}
                className="hover:opacity-70 transition-opacity shrink-0 ml-2"
              >
                <TrashIcon />
              </button>
            </div>
          ))}
        </div>
      )}

      {rows.map((rowId) => (
        <PeopleRow
          key={rowId}
          users={users}
          selected={selected}
          excluded={excluded}
          onAdd={handleAdd}
          onRemoveRow={() => handleRemoveRow(rowId)}
          canRemoveRow={allowEmptyStart || rows.length > 1 || selected.length > 0}
        />
      ))}

      <div className="flex justify-end">
        <button
            type="button"
            onClick={() => {
              // salva nome manual pendente antes de adicionar nova linha
              const pendingRow = rows[rows.length - 1]
              if (pendingRow) {
                const input = document.querySelector(`input[placeholder="Digite o nome manualmente"]`)
                if (input?.value?.trim()) {
                  const areaSelect = input.closest('.flex')?.querySelector('select')
                  const areaValue = areaSelect?.value
                  if (areaValue) {
                    onChange([...selected, { user_id: `manual_${Date.now()}`, name: input.value.trim(), area: areaValue }])
                  }
                }
              }
              handleAddRow()
            }}
            style={{ minWidth: '180px' }}
            className="h-9 px-4 text-xs font-medium bg-primary-600 text-white rounded-lg hover:bg-primary-800 transition-colors text-center"
        >
            {buttonLabel}
        </button>
      </div>
    </div>
  )
}