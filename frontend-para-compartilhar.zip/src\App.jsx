import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { ProtectedRoute } from './components/layout/ProtectedRoute'

import Login from './pages/Login'
import Register from './pages/Register'
import ForgotPassword from './pages/ForgotPassword'
import Projects from './pages/Projects'
import ProjectDetail from './pages/ProjectDetail'
import NewProject from './pages/NewProject'
import ArchivedProjects from './pages/ArchivedProjects'
import Users from './pages/Users'
import Profile from './pages/Profile'
import Notifications from './pages/Notifications'
import ApiDocs from './pages/ApiDocs'
import SamlSuccess from './pages/SamlSuccess'
import EditProject from './pages/EditProject'
import Management from './pages/Management'
import PersonalGoLive from './pages/PersonalGoLive'
import PersonalStatusReports from './pages/PersonalStatusReports'
import PersonalScopeItems from './pages/PersonalScopeItems'
import PersonalTasks from './pages/PersonalTasks'
import PersonalFeed from './pages/PersonalFeed'
import PersonalDashboard from './pages/PersonalDashboard'
import GoLiveProjects from './pages/GoLiveProjects'
import FreshServiceRequests from './pages/FreshServiceRequests'
import BacklogProjects from './pages/BacklogProjects'
import CancelledProjects from './pages/CancelledProjects'

function App() {
  return (
    <BrowserRouter>
      <Routes>

        <Route path="/login" element={<Login />} />
        <Route path="/cadastro" element={<Register />} />
        <Route path="/esqueci-senha" element={<ForgotPassword />} />

        <Route path="/auth/saml/success" element={<SamlSuccess />} />

        <Route path="/projetos" element={
          <ProtectedRoute>
            <Projects />
          </ProtectedRoute>
        } />

        <Route path="/painel" element={
          <ProtectedRoute allowedRoles={['ANALISTA_MASTER', 'ANALISTA_TESTADOR', 'GERENTE', 'COORDENADOR']}>
            <Management />
          </ProtectedRoute>
        } />

        <Route path="/projetos/novo" element={
          <ProtectedRoute>
            <NewProject />
          </ProtectedRoute>
        } />

        <Route path="/projetos/go-live" element={
          <ProtectedRoute>
            <GoLiveProjects />
          </ProtectedRoute>
        } />

        <Route path="/projetos/arquivados" element={
          <ProtectedRoute>
            <ArchivedProjects />
          </ProtectedRoute>
        } />

        <Route path="/projetos/:id" element={
          <ProtectedRoute>
            <ProjectDetail />
          </ProtectedRoute>
        } />

        <Route path="/projetos/:id/editar" element={
          <ProtectedRoute>
            <EditProject />
          </ProtectedRoute>
        } />

        <Route path="/usuarios" element={
          <ProtectedRoute allowedRoles={['ANALISTA_MASTER', 'ANALISTA_TESTADOR', 'GERENTE', 'COORDENADOR']}>
            <Users />
          </ProtectedRoute>
        } />

        <Route path="/perfil" element={
          <ProtectedRoute>
            <Profile />
          </ProtectedRoute>
        } />

        <Route path="/notificacoes" element={
          <ProtectedRoute>
            <Notifications />
          </ProtectedRoute>
        } />

        <Route path="/projetos/cancelados" element={
          <ProtectedRoute allowedRoles={['ANALISTA_MASTER', 'ANALISTA_TESTADOR', 'GERENTE', 'COORDENADOR']}>
            <CancelledProjects />
          </ProtectedRoute>
        } />

        <Route path="/painel/pessoal" element={
          <ProtectedRoute requiredArea="Tecnologia da Informação">
            <PersonalDashboard />
          </ProtectedRoute>
        } />

        <Route path="/painel/pessoal/go-live" element={
          <ProtectedRoute requiredArea="Tecnologia da Informação">
            <PersonalGoLive />
          </ProtectedRoute>
        } />

        <Route path="/painel/pessoal/status-reports" element={
          <ProtectedRoute requiredArea="Tecnologia da Informação">
            <PersonalStatusReports />
          </ProtectedRoute>
        } />

        <Route path="/painel/pessoal/atividades" element={
          <ProtectedRoute requiredArea="Tecnologia da Informação">
            <PersonalScopeItems />
          </ProtectedRoute>
        } />

        <Route path="/painel/pessoal/tarefas" element={
          <ProtectedRoute requiredArea="Tecnologia da Informação">
            <PersonalTasks />
          </ProtectedRoute>
        } />

        <Route path="/painel/pessoal/feed" element={
          <ProtectedRoute requiredArea="Tecnologia da Informação">
            <PersonalFeed />
          </ProtectedRoute>
        } />

        <Route path="/" element={<Navigate to="/projetos" replace />} />
        <Route path="*" element={<Navigate to="/projetos" replace />} />

        <Route path="/api" element={
          <ProtectedRoute allowedRoles={['ANALISTA_MASTER', 'ANALISTA_TESTADOR', 'SUPERINTENDENTE', 'DIRETOR', 'GERENTE', 'COORDENADOR', 'SUPERVISOR', 'ANALISTA']}>
            <ApiDocs />
          </ProtectedRoute>
        } />

        <Route path="/freshservice" element={
          <ProtectedRoute allowedRoles={['ANALISTA_MASTER', 'ANALISTA_TESTADOR', 'COORDENADOR', 'GERENTE', 'SUPERINTENDENTE']}>
            <FreshServiceRequests />
          </ProtectedRoute>
        } />

        <Route path="/projetos/backlog" element={
          <ProtectedRoute>
            <BacklogProjects />
          </ProtectedRoute>
        } />

      </Routes>
    </BrowserRouter>
  )
}

export default App